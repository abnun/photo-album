package de.webmpuls.photo_album

class PictureComment {

    static constraints = {
    }
}
